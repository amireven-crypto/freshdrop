# Image sources (Kofferkrieger demo)

Product photos taken from public AliExpress listings (EU storefront, fetched 22 Oct 2026). Dropshipping suppliers usually allow resellers to use listing images – **confirm with each supplier before launch**, and replace with own photos after sample orders. Resized to max 800 px, WebP.

| File | Listing | Original image URL | Listing title (as shown) | Notes |
|---|---|---|---|---|
| trunk-organizer.webp | https://www.aliexpress.com/item/1005012172931620.html | https://ae-pic-a1.aliexpress-media.com/kf/S8ba64279e9684157981bb42e1c9fa2dcZ.png | 1 Packung faltbarer Kofferraum-Organizer, robuste Stoff-Aufbewahrungsbox mit ergonomischem |  |
| dog-car-seat-cover.webp | https://www.aliexpress.com/item/1005006860985075.html | https://ae-pic-a1.aliexpress-media.com/kf/Sb6123774f3bc4041899619f622562a11W.jpg | Premium Oxford-Stoff Hunde-Autositzbezug Langlebiger Wasserdichter Kratzfester Haustier-Hä |  |
| backseat-organizer-tray.webp | https://www.aliexpress.com/item/1005011806668948.html | https://ae-pic-a1.aliexpress-media.com/kf/Sfc49957218e24b8bad411cf1e54d65d4w.jpg | 1 Stück 2026 Neuer Auto-Rücksitz-Organizer Aufbewahrungstasche Faltbares Tablett Tablet-Ha | "Car seat back organizer" overlay |
| umbrella-windshield-sunshade.webp | https://www.aliexpress.com/item/1005006553670714.html | https://ae-pic-a1.aliexpress-media.com/kf/Sce7193290d00420eb815483f24d9cf2fM.jpg | Auto Sonnenschirm Regenschirm Windschutzscheibe Klappbarer Sonnenschirm vorne Regenschirm  |  |
| magnetic-phone-mount.webp | https://www.aliexpress.com/item/1005005825400006.html | https://ae-pic-a1.aliexpress-media.com/kf/S4e53577d624d4788ba900cc4c7210ca76.jpg | Magnetischer Autotelefonhalter, Lüftungsschlitz, Clip-Halterung, 360-Grad-Drehung, mobile  |  |
| oxford-organizer.webp | https://www.aliexpress.com/item/1005008666149403.html | https://ae-pic-a1.aliexpress-media.com/kf/Se6c65bdb64d849528038960a7cacae80z.jpg | Auto Kofferraum Organizer Rücksitz Lagerung Tasche Hohe Kapazität Multi-verwenden Oxford A |  |
| under-seat-box.webp | https://www.aliexpress.com/item/1005012698650176.html | https://ae-pic-a1.aliexpress-media.com/kf/S340f7b9006c74fa8b2f386b9faa7d8f2J.jpg | Auto-Aufbewahrungsbox unter dem Sitz, ABS-Schubladenorganizer, rutschfest, universell, Aut |  |
| snow-brush-ice-scraper.webp | https://www.aliexpress.com/item/1005010089175333.html | https://ae-pic-a1.aliexpress-media.com/kf/S1b46ca12923c457bb30816daf97045642.jpg | 2-in-1 Auto-Schneebürste und Eiskratzer, Auto-Schaber, Schneebürste mit ergonomischem Scha |  |
| car-cleaning-kit.webp | https://www.aliexpress.com/item/1005007308295506.html | https://ae-pic-a1.aliexpress-media.com/kf/Sb0938c21c607448bb3c1e16405964954y.jpg | 3/5/10Pcs Auto Waschen Mikrofaser Handtuch 30*30CM / 30*60cm auto Reinigung Trocknen Tuch  | overlay "10 PCS SIZE 30x30" |
| seat-gap-filler.webp | https://www.aliexpress.com/item/1005009800425890.html | https://ae-pic-a1.aliexpress-media.com/kf/A598d5ffd96f64c19859f85761dcc249e4.jpg | 2Pcs Auto Sitz Lücke Füllstoff Sitz Spalt Lagerung Box Tasche Zwischen Sitze Konsole Organ | overlay "2PCS" |
| microfiber-towels-10.webp | https://www.aliexpress.com/item/1005007079582127.html | https://ae-pic-a1.aliexpress-media.com/kf/S02b5e99852084aae8d606addbe64ec33e.jpg | 10Pcs Mikrofaser Handtücher Auto Waschen Trocknen Tuch Handtuch Haushalt Reinigung Tücher  | image text says "50pcs" – shows a bigger pack; replace |
| drying-towel-1200.webp | https://www.aliexpress.com/item/1005008100891723.html | https://ae-pic-a1.aliexpress-media.com/kf/Sd076ef36e69244e38e3859422a72f1b0i.jpg | Autowaschhandtuch, 1200 g/m2, doppelseitiges Handtuch, Auto-Detaillierung, verdrehtes Gefl | overlay "5PCS" |
| wash-mitt-2.webp | https://www.aliexpress.com/item/1005010043971859.html | https://ae-pic-a1.aliexpress-media.com/kf/S1d81469c377543fdb414094463ebfbcaq.jpg | Größe M, Autowaschhandschuhe aus Chenille-Korallenfleece, Wasch- und Reinigungstuch, Auto- | "Random color send" overlay |
| detailing-brush-set-5.webp | https://www.aliexpress.com/item/1005006731007509.html | https://ae-pic-a1.aliexpress-media.com/kf/Sc62e323b68e44e9cb440604dc9f2d220x.jpg | Detaillierung Pinsel Set Auto Pinsel Auto Detaillierung Pinsel Für Auto Reinigung Detailli | packaging visible, check for brand print |
| wheel-brush.webp | https://www.aliexpress.com/item/1005006967540114.html | https://ae-pic-a1.aliexpress-media.com/kf/S9d9318b59ce244768c9ee3614207e9c1a.png | Auto-Radbürste, Felge, Reifendetails, Automobilpflege, Motorräder, Bürste, Radreinigungsbü |  |
| applicator-pads-5.webp | https://www.aliexpress.com/item/1005007938001638.html | https://ae-pic-a1.aliexpress-media.com/kf/S16675f5713774a3587de8cd5e59ed020d.jpg | 10Pcs Auto Detaillierung Applikator Pads Auto Pflege Wachsen Polnischen Schwämme Weiche Mi | overlay "1-10Pcs" |
| windshield-frost-cover.webp | https://www.aliexpress.com/item/1005008248188066.html | https://ae-pic-a1.aliexpress-media.com/kf/S3248e042b07a490fb74f485f327bc1dfm.jpg | Allwetter-Magnetische Windschutzscheibenabdeckung ​   Wasserdichter Schnee-/Frost-/Eisschu | small seller badge top-left |
| steering-wheel-cover.webp | https://www.aliexpress.com/item/1005007128062968.html | https://ae-pic-a1.aliexpress-media.com/kf/S854ddf5633564be3a12735f8714ab92eP.jpg | Universeller Leder-Auto-Lenkrad-Stich-On-Wrap-Cover, passend für 38 cm 14 Zoll DIY Nähen,  |  |
| neck-pillow.webp | https://www.aliexpress.com/item/1005007171093572.html | https://ae-pic-a1.aliexpress-media.com/kf/Sb731c09bab21467f8225304bc39b2a8el.png | Memory Foam Auto Nacken kissen Auto Lordos stütze für Auto liefert Universal Nacken kissen | photo shows neck + lumbar cushion |
| neck-lumbar-set.webp | https://www.aliexpress.com/item/1005007049671921.html | https://ae-pic-a1.aliexpress-media.com/kf/S0f80ea7e6c5946ccbe0f3fb162887e53b.png | Auto Memory Foam Kopfstütze Set Auto Hals Kissen Auto Lenden Taille Kissen Taille Unterstü | small emblem on pillow – check |
| glass-towels-3.webp | https://www.aliexpress.com/item/4001252645529.html | https://ae01.alicdn.com/kf/H7aa6f89cb2d2469a9fcd914b518bd210T.jpg | 40x40cm Car Wash Towel Glass Cleaning ... Waffle Weave Towel (via alitools.io) | via alitools.io mirror of listing 4001252645529 |
| bundle-detailing-starter.webp | – | – | collage of: microfiber-towels-10, wash-mitt-2, detailing-brush-set-5, applicator-pads-5 | generated locally |
| bundle-tidy-car.webp | – | – | collage of: trunk-organizer, seat-gap-filler | generated locally |
| bundle-on-the-road-with-dog.webp | – | – | collage of: dog-car-seat-cover, microfiber-towels-10 | generated locally |
| bundle-winter.webp | – | – | collage of: snow-brush-ice-scraper, car-cleaning-kit | generated locally |

## Batch 4 (26 Oct 2026) - unique replacement photos from Pexels (Pexels License: free for commercial use, no attribution required)

| File | Source | Page URL | Image URL | Licence | Photographer |
|---|---|---|---|---|---|
| magnetic-dashboard-mount.webp | Pexels | https://www.pexels.com/photo/close-up-photography-of-iphone-6-694424/ | https://images.pexels.com/photos/694424/pexels-photo-694424.jpeg | Pexels License | Mustafa ezz |
| magnetic-vent-mount.webp | Pexels | https://www.pexels.com/photo/close-up-of-a-magnetic-phone-holder-13536013/ | https://images.pexels.com/photos/13536013/pexels-photo-13536013.jpeg | Pexels License | Abdulvahap Demir |
| magnetic-cd-slot-mount.webp | Pexels | https://www.pexels.com/photo/a-smartphone-with-displayed-directions-attached-next-to-the-steering-wheel-in-a-car-17445146/ | https://images.pexels.com/photos/17445146/pexels-photo-17445146.jpeg | Pexels License | iddea photo |
| magnetic-mirror-mount.webp | Pexels | https://www.pexels.com/photo/car-interior-with-rearview-mirror-and-dashboard-38712727/ | https://images.pexels.com/photos/38712727/pexels-photo-38712727.jpeg | Pexels License |  |
| suction-cup-windshield-phone-mount.webp | Pexels | https://www.pexels.com/photo/green-nokia-smartphone-1412214/ | https://images.pexels.com/photos/1412214/pexels-photo-1412214.jpeg | Pexels License | Malte Luk |
| motorcycle-handlebar-phone-mount.webp | Pexels | https://www.pexels.com/photo/black-handlebars-of-a-motorbike-with-phone-holder-12463267/ | https://images.pexels.com/photos/12463267/pexels-photo-12463267.jpeg | Pexels License | Break Media |
| magnetic-mini-phone-holder.webp | Pexels | https://www.pexels.com/photo/close-up-of-the-directions-on-a-smartphone-5025655/ | https://images.pexels.com/photos/5025655/pexels-photo-5025655.jpeg | Pexels License | Artem Podrez |
| extra-long-wheel-brush.webp | Pexels | https://www.pexels.com/photo/a-close-up-shot-of-a-person-brushing-a-car-6873010/ | https://images.pexels.com/photos/6873010/pexels-photo-6873010.jpeg | Pexels License |  |
| interior-dusting-brush.webp | Pexels | https://www.pexels.com/photo/black-steel-brush-45059/ | https://images.pexels.com/photos/45059/pexels-photo-45059.jpeg | Pexels License |  |
| scrub-brush-mats.webp | Pexels | https://www.pexels.com/photo/photo-of-a-brush-with-black-bristles-9230397/ | https://images.pexels.com/photos/9230397/pexels-photo-9230397.jpeg | Pexels License |  |
| crevice-vent-brush-set.webp | Pexels | https://www.pexels.com/photo/cleaning-brush-and-soap-on-marble-table-4202467/ | https://images.pexels.com/photos/4202467/pexels-photo-4202467.jpeg | Pexels License |  |
| microfiber-towels-40-6.webp | Pexels | https://www.pexels.com/photo/close-up-photo-of-cleaning-of-car-7154635/ | https://images.pexels.com/photos/7154635/pexels-photo-7154635.jpeg | Pexels License |  |
| microfiber-towels-30-20.webp | Pexels | https://www.pexels.com/photo/crop-person-wiping-modern-car-panel-4218867/ | https://images.pexels.com/photos/4218867/pexels-photo-4218867.jpeg | Pexels License |  |
| large-microfiber-towel-60x90.webp | Pexels | https://www.pexels.com/photo/hand-wiping-a-car-with-a-cloth-14615260/ | https://images.pexels.com/photos/14615260/pexels-photo-14615260.jpeg | Pexels License |  |
| waffle-glass-polish-towel.webp | Pexels | https://www.pexels.com/photo/blue-cloth-on-the-wooden-chair-4794851/ | https://images.pexels.com/photos/4794851/pexels-photo-4794851.jpeg | Pexels License |  |
| dog-grooming-brush.webp | Pexels | https://www.pexels.com/photo/a-person-brushing-her-dog-s-fur-8498855/ | https://images.pexels.com/photos/8498855/pexels-photo-8498855.jpeg | Pexels License |  |
| dog-paw-cleaning-brush.webp | Pexels | https://www.pexels.com/photo/a-man-with-his-dog-in-the-kitchen-5483443/ | https://images.pexels.com/photos/5483443/pexels-photo-5483443.jpeg | Pexels License |  |
| pet-hair-rubber-brush.webp | Pexels | https://www.pexels.com/photo/a-person-deep-cleaning-a-car-seat-5233285/ | https://images.pexels.com/photos/5233285/pexels-photo-5233285.jpeg | Pexels License |  |
| dog-car-seat-belt-harness.webp | Pexels | https://www.pexels.com/photo/a-cute-dog-in-a-car-16605513/ | https://images.pexels.com/photos/16605513/pexels-photo-16605513.jpeg | Pexels License |  |
| dog-car-water-bottle.webp | Pexels | https://www.pexels.com/photo/brown-and-white-dog-drinking-water-8132361/ | https://images.pexels.com/photos/8132361/pexels-photo-8132361.jpeg | Pexels License |  |
| pet-hair-roller.webp | Pexels | https://www.pexels.com/photo/woman-using-lint-remover-6865185/ | https://images.pexels.com/photos/6865185/pexels-photo-6865185.jpeg | Pexels License |  |

Notes: images are the closest honest match (stock photos, not the actual products); replace with own product photos after sample orders. Mirror, CD-slot, mini mount, vent brush set, scrub brush and waffle towel photos are illustrative (nearest available). Previous duplicate files are backed up in ..\img_bak4.

### Corrections (26 Oct 2026, later)

| File | Source | Page URL | Licence | Notes |
|---|---|---|---|---|
| magnetic-dashboard-mount.webp | Pexels | https://www.pexels.com/photo/cellphone-on-a-stand-with-navigation-map-application-open-7738879/ | Pexels License (Caleb Oquendo) | replaces 694424; phone on dashboard mount (mount type not visibly magnetic) |
| magnetic-cd-slot-mount.webp | Wikimedia Commons | https://commons.wikimedia.org/wiki/File:CD_Slot_Mount.png | CC BY-SA 3.0 - author G Smith | REQUIRES ATTRIBUTION (+ share-alike) if the site goes public; real CD-slot mount photo, older phone, not magnetic; replaces 17445146 (which is no longer used) |

### Second pass (26 Oct 2026)

| File | Source | Page URL | Licence | Notes |
|---|---|---|---|---|
| crevice-vent-brush-set.webp | Pikwizard | https://pikwizard.com/photo/brushing-car-air-vent-grille-with-small-brush-raising-dust-particles-close-up-interior/278deee0b329a6468ce6867691e5a61e/ | Pikwizard free licence (personal and commercial use) | small brush on a vent grille; image looks AI-generated; replaces Pexels 4202467 |
| scrub-brush-mats.webp | Pikwizard | https://pikwizard.com/photo/man-cleaning-car-upholstery-with-brush-in-back-seat/a88ffae7778d25fed43cc029d4c12bca/ | Pikwizard free licence (personal and commercial use) | hand brush on car back seat upholstery; replaces Pexels 9230397 |

## Third pass (AI-generated, 26 Oct 2026)
- pet-hair-rubber-brush, dog-paw-cleaning-brush, magnetic-dashboard-mount, magnetic-cd-slot-mount, magnetic-mirror-mount: AI-generated illustrations of the product (own work, no third-party licence). Replace with real product photos before launch if desired.


## Oct 26 2026 - 34 new products (80 items total)
The 34 new general-merchandise products have NO photo yet: they show the built-in SVG category illustration. Real photos could not be sourced (Pexels/Pixabay/Unsplash block automated access; Wikimedia Commons had no usable product photos). No existing image was changed or replaced. Add real, licensed photos as assets/img/<id>.webp (record source URL + licence here).

## Fourth pass - AI-generated product images (26 Oct 2026), user-approved
The 35 products that had no photo now carry an AI-generated studio-style product image (generated with the Grok Bot image tool; own work, no third-party licence, no stock photo involved). Approved by the shop owner for products with no image only. Replace with real licensed photos before launch if desired. Format: 800x800 webp, white background.
Ids: foldable-storage-boxes-3 vacuum-storage-bags non-slip-clothes-hangers-20 foldable-laundry-basket drawer-organizer-set led-motion-night-lights-2 adhesive-wall-hooks-20 shoe-rack silicone-utensil-set bamboo-cutting-board glass-food-storage-set silicone-baking-mat cork-trivet digital-kitchen-scale a4-printer-paper-500 desk-organizer aluminium-laptop-stand a5-notebooks-3 xl-mouse-pad clumping-cat-litter cat-scratching-post retractable-dog-leash washable-pet-bed toilet-paper-24 flat-microfibre-mop sponge-set telescopic-duster reusable-lint-roller cotton-bath-towel-set non-slip-bath-mat wall-shower-caddy screwdriver-bit-set rechargeable-led-flashlight packing-cubes-set waterproof-travel-pouch

## Oct 26 2026 - new products (S & G category, extra Tools)
The 8 new Tools products (folding-camping-shovel, garden-hand-trowel, snow-shovel, led-flashlight-aaa, led-headlamp-aaa, pocket-torch-aa, measuring-tape-5m, adjustable-wrench) and the 8 new S & G products (plastic-sports-water-bottle, shaker-bottle, gym-bottle-with-straw, collapsible-water-bottle, resistance-bands-set, skipping-rope, yoga-mat, microfibre-gym-towel) have NO photo yet: they show the built-in SVG illustration. Real free photos could not be fetched (Pexels 403, Pixabay 403, Unsplash 401, Pikwizard 403, Wikimedia 429 from automated access). Add real, licensed photos as assets/img/<id>.webp and log source + licence here.
